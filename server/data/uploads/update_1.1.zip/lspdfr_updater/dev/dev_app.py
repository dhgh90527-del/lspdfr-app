"""
LSPDFR Custom Pack - Dev Tool
=============================
Simple internal tool (UI doesn't need to be pretty) for you as the dev to:
 - Push a new update (a .zip of files) to players
 - See how many people have installed each version
 - Send an announcement that shows up in the player app's Home tab

Build to .exe with: pyinstaller --onefile --windowed --name LSPDFR_DevTool dev_app.py
(run that on Windows - see build_exe.bat)
"""

import json
import os
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import requests

APP_DIR = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "LSPDFRDevTool")
CONFIG_PATH = os.path.join(APP_DIR, "dev_config.json")
os.makedirs(APP_DIR, exist_ok=True)

DEFAULT_CONFIG = {"server_url": "http://YOUR-SERVER-ADDRESS:5000", "dev_token": ""}


def load_config():
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return dict(DEFAULT_CONFIG)


def save_config(cfg):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)


class DevApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.cfg = load_config()
        self.title("LSPDFR Dev Tool")
        self.geometry("560x480")

        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True)

        self.push_tab = tk.Frame(notebook)
        self.stats_tab = tk.Frame(notebook)
        self.announce_tab = tk.Frame(notebook)
        self.settings_tab = tk.Frame(notebook)
        notebook.add(self.push_tab, text="Push Update")
        notebook.add(self.stats_tab, text="Stats")
        notebook.add(self.announce_tab, text="Announcement")
        notebook.add(self.settings_tab, text="Settings")

        self.build_push_tab()
        self.build_stats_tab()
        self.build_announce_tab()
        self.build_settings_tab()

    # -------------------- PUSH UPDATE --------------------
    def build_push_tab(self):
        pad = {"padx": 15, "pady": 6}
        tk.Label(self.push_tab, text="Version (e.g. 1.0.1):").pack(anchor="w", **pad)
        self.version_var = tk.StringVar()
        tk.Entry(self.push_tab, textvariable=self.version_var).pack(fill="x", padx=15)

        tk.Label(self.push_tab, text="Changelog / notes:").pack(anchor="w", **pad)
        self.notes_box = tk.Text(self.push_tab, height=6)
        self.notes_box.pack(fill="x", padx=15)

        tk.Label(self.push_tab, text="Update .zip file:").pack(anchor="w", **pad)
        row = tk.Frame(self.push_tab)
        row.pack(fill="x", padx=15)
        self.zip_path_var = tk.StringVar()
        tk.Entry(row, textvariable=self.zip_path_var).pack(side="left", fill="x", expand=True)
        tk.Button(row, text="Browse...", command=self.browse_zip).pack(side="left", padx=(8, 0))

        tk.Button(self.push_tab, text="Push Update", command=self.push_update).pack(pady=15)
        self.push_status = tk.Label(self.push_tab, text="")
        self.push_status.pack()

    def browse_zip(self):
        path = filedialog.askopenfilename(title="Select update zip", filetypes=[("Zip files", "*.zip")])
        if path:
            self.zip_path_var.set(path)

    def push_update(self):
        version = self.version_var.get().strip()
        notes = self.notes_box.get("1.0", "end").strip()
        zip_path = self.zip_path_var.get().strip()
        if not version or not zip_path:
            messagebox.showerror("Missing info", "Version and a zip file are required.")
            return
        if not os.path.exists(zip_path):
            messagebox.showerror("File not found", "Couldn't find that zip file.")
            return
        try:
            with open(zip_path, "rb") as f:
                resp = requests.post(
                    self.cfg["server_url"] + "/upload",
                    data={"version": version, "notes": notes, "token": self.cfg["dev_token"]},
                    files={"file": f},
                    timeout=60,
                )
            data = resp.json()
            if data.get("ok"):
                self.push_status.config(text=f"Update {version} pushed successfully!")
                messagebox.showinfo("Success", f"Update {version} is now live for players.")
            else:
                self.push_status.config(text=f"Failed: {data.get('error')}")
        except Exception as e:
            self.push_status.config(text=f"Error: {e}")

    # -------------------- STATS --------------------
    def build_stats_tab(self):
        tk.Button(self.stats_tab, text="Refresh Stats", command=self.refresh_stats).pack(pady=10)
        columns = ("version", "notes", "installs")
        self.tree = ttk.Treeview(self.stats_tab, columns=columns, show="headings")
        self.tree.heading("version", text="Version")
        self.tree.heading("notes", text="Notes")
        self.tree.heading("installs", text="Installs")
        self.tree.column("version", width=90)
        self.tree.column("notes", width=280)
        self.tree.column("installs", width=80, anchor="center")
        self.tree.pack(fill="both", expand=True, padx=15, pady=5)

        self.current_version_label = tk.Label(self.stats_tab, text="Current live version: -")
        self.current_version_label.pack(pady=5)

    def refresh_stats(self):
        try:
            resp = requests.get(
                self.cfg["server_url"] + "/stats", params={"token": self.cfg["dev_token"]}, timeout=10
            )
            data = resp.json()
        except Exception as e:
            messagebox.showerror("Error", str(e))
            return
        if not data.get("ok", True) and "error" in data:
            messagebox.showerror("Error", data["error"])
            return

        for row in self.tree.get_children():
            self.tree.delete(row)
        for version, info in data.get("updates", {}).items():
            self.tree.insert("", "end", values=(version, info.get("notes", ""), info.get("installs", 0)))
        self.current_version_label.config(text=f"Current live version: {data.get('current_version')}")

    # -------------------- ANNOUNCEMENT --------------------
    def build_announce_tab(self):
        tk.Label(self.announce_tab, text="Message shown to everyone using the app:").pack(
            anchor="w", padx=15, pady=(15, 5)
        )
        self.announce_box = tk.Text(self.announce_tab, height=10)
        self.announce_box.pack(fill="both", expand=True, padx=15)
        tk.Button(self.announce_tab, text="Send Announcement", command=self.send_announcement).pack(pady=10)
        self.announce_status = tk.Label(self.announce_tab, text="")
        self.announce_status.pack()

    def send_announcement(self):
        text = self.announce_box.get("1.0", "end").strip()
        try:
            resp = requests.post(
                self.cfg["server_url"] + "/announcement",
                json={"text": text, "token": self.cfg["dev_token"]},
                timeout=10,
            )
            data = resp.json()
            if data.get("ok"):
                self.announce_status.config(text="Announcement sent!")
            else:
                self.announce_status.config(text=f"Failed: {data.get('error')}")
        except Exception as e:
            self.announce_status.config(text=f"Error: {e}")

    # -------------------- SETTINGS --------------------
    def build_settings_tab(self):
        pad = {"padx": 15, "pady": 6}
        tk.Label(self.settings_tab, text="Server address:").pack(anchor="w", **pad)
        self.server_var = tk.StringVar(value=self.cfg.get("server_url", ""))
        tk.Entry(self.settings_tab, textvariable=self.server_var).pack(fill="x", padx=15)

        tk.Label(self.settings_tab, text="Dev token (must match server.py):").pack(anchor="w", **pad)
        self.token_var = tk.StringVar(value=self.cfg.get("dev_token", ""))
        tk.Entry(self.settings_tab, textvariable=self.token_var, show="*").pack(fill="x", padx=15)

        tk.Button(self.settings_tab, text="Save", command=self.save_settings).pack(pady=15)

    def save_settings(self):
        self.cfg["server_url"] = self.server_var.get().strip()
        self.cfg["dev_token"] = self.token_var.get().strip()
        save_config(self.cfg)
        messagebox.showinfo("Saved", "Settings saved.")


if __name__ == "__main__":
    DevApp().mainloop()
