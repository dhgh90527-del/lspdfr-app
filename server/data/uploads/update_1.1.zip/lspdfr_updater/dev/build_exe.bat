@echo off
echo Installing dependencies...
pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo pip install failed - see the error above. Fix that first, then re-run this script.
    pause
    exit /b 1
)

echo.
echo Building exe with PyInstaller...
python -m PyInstaller --onefile --windowed --name LSPDFR_DevTool dev_app.py
if errorlevel 1 (
    echo.
    echo PyInstaller build failed - see the error above.
    pause
    exit /b 1
)

echo.
echo Done! Find LSPDFR_DevTool.exe inside the "dist" folder.
pause
