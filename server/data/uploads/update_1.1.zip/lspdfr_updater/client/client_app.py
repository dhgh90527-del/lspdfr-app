"""
LSPDFR Custom Pack - Player App
===============================
First run: asks the player where GTA5.exe is installed.
Then: a normal window with Home / Updates / Settings.
The Updates tab checks the server, and if there's a new version it
downloads the .zip and extracts it straight into the GTA5 folder for you.

Build to .exe with: pyinstaller --onefile --windowed --name LSPDFR_Updater client_app.py
(run that on Windows - see build_exe.bat)
"""

import json
import os
import shutil
import tempfile
import threading
import tkinter as tk
import zipfile
from tkinter import filedialog, messagebox, ttk

import requests

# ----------------------------------------------------------------------
# CONFIG - change this to point at your server before you build the exe
# ----------------------------------------------------------------------
DEFAULT_SERVER_URL = "http://YOUR-SERVER-ADDRESS:5000"
# ----------------------------------------------------------------------

APP_DIR = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "LSPDFRCustomUpdater")
CONFIG_PATH = os.path.join(APP_DIR, "config.json")

os.makedirs(APP_DIR, exist_ok=True)


def load_config():
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"gta5_path": "", "server_url": DEFAULT_SERVER_URL, "installed_version": None}


def save_config(cfg):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)


def is_valid_gta5_folder(path):
    return bool(path) and os.path.isfile(os.path.join(path, "GTA5.exe"))


# ======================================================================
# FIRST-RUN SETUP WIZARD
# ======================================================================
class SetupWizard(tk.Tk):
    def __init__(self, on_done):
        super().__init__()
        self.on_done = on_done
        self.title("Welcome - LSPDFR Custom Pack")
        self.geometry("520x260")
        self.resizable(False, False)
        self.configure(bg="#1e1e24")

        tk.Label(
            self, text="Welcome to the LSPDFR Custom Pack!",
            font=("Segoe UI", 16, "bold"), bg="#1e1e24", fg="white",
        ).pack(pady=(30, 10))

        tk.Label(
            self,
            text="Before we start, tell us where GTA5.exe is installed\n"
                 "so updates can be installed automatically.",
            font=("Segoe UI", 10), bg="#1e1e24", fg="#cccccc", justify="center",
        ).pack(pady=(0, 20))

        row = tk.Frame(self, bg="#1e1e24")
        row.pack(pady=5)
        self.path_var = tk.StringVar()
        tk.Entry(row, textvariable=self.path_var, width=45).pack(side="left", padx=(0, 8))
        tk.Button(row, text="Browse...", command=self.browse).pack(side="left")

        self.status_label = tk.Label(self, text="", bg="#1e1e24", fg="#ff6b6b")
        self.status_label.pack(pady=5)

        tk.Button(
            self, text="Continue", font=("Segoe UI", 11, "bold"),
            bg="#3d7dff", fg="white", relief="flat", padx=20, pady=8,
            command=self.confirm,
        ).pack(pady=15)

    def browse(self):
        folder = filedialog.askdirectory(title="Select your GTA5 install folder")
        if folder:
            self.path_var.set(folder)

    def confirm(self):
        path = self.path_var.get().strip()
        if not is_valid_gta5_folder(path):
            self.status_label.config(text="Couldn't find GTA5.exe in that folder - please check it.")
            return
        cfg = load_config()
        cfg["gta5_path"] = path
        save_config(cfg)
        self.destroy()
        self.on_done()


# ======================================================================
# MAIN APP
# ======================================================================
class MainApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.config_data = load_config()
        self.title("LSPDFR Custom Pack")
        self.geometry("640x460")
        self.minsize(560, 400)

        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        header = tk.Frame(self, bg="#14141a", height=60)
        header.pack(fill="x")
        tk.Label(
            header, text="LSPDFR Custom Pack", font=("Segoe UI", 15, "bold"),
            bg="#14141a", fg="white",
        ).pack(side="left", padx=20, pady=15)

        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True)

        self.home_tab = tk.Frame(notebook)
        self.updates_tab = tk.Frame(notebook)
        self.settings_tab = tk.Frame(notebook)
        notebook.add(self.home_tab, text="  Home  ")
        notebook.add(self.updates_tab, text="  Updates  ")
        notebook.add(self.settings_tab, text="  Settings  ")

        self.build_home_tab()
        self.build_updates_tab()
        self.build_settings_tab()

        self.refresh_home()
        self.refresh_update_status()

    # -------------------- HOME TAB --------------------
    def build_home_tab(self):
        tk.Label(self.home_tab, text="Announcements", font=("Segoe UI", 13, "bold")).pack(
            anchor="w", padx=20, pady=(20, 5)
        )
        self.announcement_text = tk.Text(self.home_tab, height=10, wrap="word", state="disabled")
        self.announcement_text.pack(fill="both", expand=True, padx=20, pady=5)
        tk.Button(self.home_tab, text="Refresh", command=self.refresh_home).pack(pady=10)

    def refresh_home(self):
        def worker():
            try:
                r = requests.get(self.config_data["server_url"] + "/announcement", timeout=8)
                text = r.json().get("announcement", "")
            except Exception as e:
                text = f"(Couldn't reach server: {e})"
            self.after(0, lambda: self._set_announcement_text(text))
        threading.Thread(target=worker, daemon=True).start()

    def _set_announcement_text(self, text):
        self.announcement_text.config(state="normal")
        self.announcement_text.delete("1.0", "end")
        self.announcement_text.insert("1.0", text)
        self.announcement_text.config(state="disabled")

    # -------------------- UPDATES TAB --------------------
    def build_updates_tab(self):
        pad = {"padx": 20, "pady": 6}
        tk.Label(self.updates_tab, text="Updates", font=("Segoe UI", 13, "bold")).pack(anchor="w", **pad)

        self.installed_label = tk.Label(self.updates_tab, text="Installed version: unknown")
        self.installed_label.pack(anchor="w", **pad)

        self.latest_label = tk.Label(self.updates_tab, text="Latest version: (check below)")
        self.latest_label.pack(anchor="w", **pad)

        self.notes_text = tk.Text(self.updates_tab, height=6, wrap="word", state="disabled")
        self.notes_text.pack(fill="x", padx=20, pady=6)

        btn_row = tk.Frame(self.updates_tab)
        btn_row.pack(**pad)
        tk.Button(btn_row, text="Check for Updates", command=self.check_for_updates).pack(side="left", padx=5)
        self.install_btn = tk.Button(
            btn_row, text="Download && Install", command=self.start_install, state="disabled"
        )
        self.install_btn.pack(side="left", padx=5)

        self.progress = ttk.Progressbar(self.updates_tab, orient="horizontal", mode="determinate", length=400)
        self.progress.pack(padx=20, pady=15)

        self.status_label = tk.Label(self.updates_tab, text="")
        self.status_label.pack(padx=20)

        self._latest_info = None

    def refresh_update_status(self):
        self.installed_label.config(
            text=f"Installed version: {self.config_data.get('installed_version') or 'none installed yet'}"
        )

    def check_for_updates(self):
        self.status_label.config(text="Checking for updates...")

        def worker():
            try:
                r = requests.get(self.config_data["server_url"] + "/manifest", timeout=10)
                data = r.json()
            except Exception as e:
                self.after(0, lambda: self.status_label.config(text=f"Error contacting server: {e}"))
                return
            self.after(0, lambda: self._handle_manifest(data))
        threading.Thread(target=worker, daemon=True).start()

    def _handle_manifest(self, data):
        version = data.get("version")
        if not version:
            self.status_label.config(text="No updates have been published yet.")
            return
        self._latest_info = data
        self.latest_label.config(text=f"Latest version: {version}")
        self.notes_text.config(state="normal")
        self.notes_text.delete("1.0", "end")
        self.notes_text.insert("1.0", data.get("notes", ""))
        self.notes_text.config(state="disabled")

        if version == self.config_data.get("installed_version"):
            self.status_label.config(text="You're already up to date!")
            self.install_btn.config(state="disabled")
        else:
            self.status_label.config(text="A new update is available.")
            self.install_btn.config(state="normal")

    def start_install(self):
        if not self._latest_info:
            return
        if not is_valid_gta5_folder(self.config_data.get("gta5_path", "")):
            messagebox.showerror("GTA5 folder not set", "Please set your GTA5 folder in Settings first.")
            return
        self.install_btn.config(state="disabled")
        self.status_label.config(text="Downloading update...")
        self.progress["value"] = 0

        version = self._latest_info["version"]
        url = self._latest_info["download_url"]
        threading.Thread(target=self._download_and_install, args=(url, version), daemon=True).start()

    def _download_and_install(self, url, version):
        try:
            r = requests.get(url, stream=True, timeout=30)
            r.raise_for_status()
            total = int(r.headers.get("content-length", 0))
            downloaded = 0

            tmp_fd, tmp_path = tempfile.mkstemp(suffix=".zip")
            with os.fdopen(tmp_fd, "wb") as f:
                for chunk in r.iter_content(chunk_size=65536):
                    if not chunk:
                        continue
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total:
                        pct = downloaded / total * 100
                        self.after(0, lambda p=pct: self.progress.config(value=p))

            self.after(0, lambda: self.status_label.config(text="Installing into your GTA5 folder..."))

            gta_path = self.config_data["gta5_path"]
            with zipfile.ZipFile(tmp_path, "r") as zf:
                zf.extractall(gta_path)

            os.remove(tmp_path)

            self.config_data["installed_version"] = version
            save_config(self.config_data)

            try:
                requests.post(
                    self.config_data["server_url"] + "/report_install",
                    json={"version": version},
                    timeout=8,
                )
            except Exception:
                pass  # non-critical if this fails

            self.after(0, self._install_done, version)
        except Exception as e:
            self.after(0, lambda: self.status_label.config(text=f"Install failed: {e}"))
            self.after(0, lambda: self.install_btn.config(state="normal"))

    def _install_done(self, version):
        self.progress["value"] = 100
        self.status_label.config(text=f"Update {version} installed successfully!")
        self.refresh_update_status()
        messagebox.showinfo("Update installed", f"Version {version} was installed into your GTA5 folder.")

    # -------------------- SETTINGS TAB --------------------
    def build_settings_tab(self):
        pad = {"padx": 20, "pady": 8}
        tk.Label(self.settings_tab, text="Settings", font=("Segoe UI", 13, "bold")).pack(anchor="w", **pad)

        tk.Label(self.settings_tab, text="GTA5 folder:").pack(anchor="w", padx=20)
        row1 = tk.Frame(self.settings_tab)
        row1.pack(fill="x", padx=20, pady=(0, 10))
        self.gta_path_var = tk.StringVar(value=self.config_data.get("gta5_path", ""))
        tk.Entry(row1, textvariable=self.gta_path_var).pack(side="left", fill="x", expand=True)
        tk.Button(row1, text="Browse...", command=self.browse_gta_path).pack(side="left", padx=(8, 0))

        tk.Label(self.settings_tab, text="Server address:").pack(anchor="w", padx=20)
        self.server_var = tk.StringVar(value=self.config_data.get("server_url", DEFAULT_SERVER_URL))
        tk.Entry(self.settings_tab, textvariable=self.server_var).pack(fill="x", padx=20, pady=(0, 10))

        tk.Button(self.settings_tab, text="Save Settings", command=self.save_settings).pack(padx=20, pady=10)

    def browse_gta_path(self):
        folder = filedialog.askdirectory(title="Select your GTA5 install folder")
        if folder:
            self.gta_path_var.set(folder)

    def save_settings(self):
        path = self.gta_path_var.get().strip()
        if not is_valid_gta5_folder(path):
            messagebox.showerror("Invalid folder", "GTA5.exe was not found in that folder.")
            return
        self.config_data["gta5_path"] = path
        self.config_data["server_url"] = self.server_var.get().strip()
        save_config(self.config_data)
        messagebox.showinfo("Saved", "Settings saved.")


def main():
    cfg = load_config()
    if is_valid_gta5_folder(cfg.get("gta5_path", "")):
        MainApp().mainloop()
    else:
        def launch_main():
            MainApp().mainloop()
        SetupWizard(on_done=launch_main).mainloop()


if __name__ == "__main__":
    main()
