# LSPDFR Custom Pack — Updater System

Three pieces, all included:

```
server/   -> the "middleman" both apps talk to (you host this)
client/   -> the app your players run (LSPDFR_Updater.exe)
dev/      -> the app only you run (LSPDFR_DevTool.exe)
```

**Important, read first:** I built and wrote all the code here, but I put it
together in a Linux sandbox, so I can't compile the actual Windows `.exe`
files myself — `.exe` binaries need to be built on Windows. Everything below
gets you from these source files to real `.exe` files in a few minutes.

## How it fits together

1. `server` is a small Flask web app. It stores the latest update file,
   counts installs, and stores your announcement text. You need to run
   this somewhere reachable by your players — your own PC (with port
   forwarding), a cheap VPS, or a free host like Render/PythonAnywhere.
2. `client` is `LSPDFR_Updater.exe` — this is what you give to players.
   First launch asks them to point it at their GTA5 folder. It has
   Home / Updates / Settings tabs. Checking for updates hits your server;
   if there's a new version it downloads the zip and extracts it straight
   into their GTA5 folder automatically.
3. `dev` is `LSPDFR_DevTool.exe` — only for you. Push new update zips,
   see install counts per version, and send announcements that show up
   in the player app's Home tab.

## Step 1 — Set up the server

```
cd server
pip install -r requirements.txt
```

Open `server.py` and change this line to something only you know:

```python
DEV_TOKEN = "changeme-super-secret-token"
```

Then run it:

```
python server.py
```

It'll print the address it's running on (default port 5000). If you're
testing locally, that's `http://127.0.0.1:5000`. To actually reach players
over the internet, you'll need to either port-forward, or deploy it to a
host (a small VPS running this with `python server.py`, or behind
something like `gunicorn` + nginx for anything serious). This part is on
you since it depends on where you want to host it — happy to help set up
a specific host if you tell me which one you want to use.

## Step 2 — Build the player app (.exe)

On a **Windows machine**:

```
cd client
```

Open `client_app.py` and set:

```python
DEFAULT_SERVER_URL = "http://YOUR-SERVER-ADDRESS:5000"
```

to your real server address, then run:

```
build_exe.bat
```

This installs dependencies and runs PyInstaller. Your finished app appears
at `client\dist\LSPDFR_Updater.exe`. That's the file you send to players.

## Step 3 — Build the dev app (.exe)

Also on Windows:

```
cd dev
build_exe.bat
```

Finished app: `dev\dist\LSPDFR_DevTool.exe`. Run it, go to **Settings**,
and enter your server address + the same `DEV_TOKEN` you set in
`server.py`. Now you can push updates, check stats, and send announcements.

## Using it day to day

- **To ship an update:** zip up the mod files exactly as they should land
  inside the GTA5 folder (matching subfolders and all), open the dev
  app's "Push Update" tab, give it a version number + changelog, and hit
  Push. Players who click "Check for Updates" will see it and can
  install with one click.
- **To see adoption:** dev app → Stats tab → Refresh. Shows installs per
  version.
- **To message players:** dev app → Announcement tab → type your message
  → Send. It shows up on the player app's Home tab next time they open
  it or hit Refresh.

## Notes / things worth knowing

- The player app stores its settings in
  `%APPDATA%\LSPDFRCustomUpdater\config.json`, so it survives reinstalls
  of the exe itself.
- The dev token check is basic (a shared secret in a URL/body) — fine for
  a small mod community, but if this ever needs to be bulletproof, put
  the server behind HTTPS and consider a stronger auth scheme.
- The updater extracts the zip directly into the GTA5 folder, so build
  your update zips with the right internal folder structure (e.g. if a
  file needs to go in `GTA5\plugins\lspdfr\...`, the zip should contain
  that same path).
